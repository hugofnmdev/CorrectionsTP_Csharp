namespace Factory06
{
    public enum MachineType
    {
        Hat = 0,
        Flask,
        Coat
    }
}
