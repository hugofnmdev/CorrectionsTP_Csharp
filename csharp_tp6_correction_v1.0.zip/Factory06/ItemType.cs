﻿namespace Factory06
{
    public enum ItemType
    {
        Hat = 2,
        Coat = 7,
        Flask = 21
    }
}