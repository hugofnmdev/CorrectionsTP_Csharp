﻿namespace Reference
{
    public enum MachinePrice
    {
        Hat = 90,
        Coat = 120,
        Flask = 200
    }
}