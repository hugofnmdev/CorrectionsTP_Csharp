namespace Reference
{
    public enum MachineType
    {
        Hat = 0,
        Flask,
        Coat
    }
}
