Le but est de trouver un mot de passe.

La confirmation du mot de passe est définie dans la fonction
``Program.sadkjhaksfdh``.

En regardant la backtrace :

- ``Program.sadkjhaksfdh``
- ``Dummy.mnbvcjhiuu`` case 13
- ``Dummy.poiurewq`` case 0x6e
- ``Dummy.dogecoin`` case 0x69
- ``Dummy.pouet`` case 103
- ``Dummy.nani`` case 0x30
- ``Dummy.qmkowirjflsak`` case 108
- ``Dummy.qwoeiulkajsdf`` case 111
- ``Dummy.zxcvasdfqwer`` case 114
- ``Dummy.vcxzpoiu`` case 80
- ``Program.are_you_leet_enough``
- ``Program.Main``

Les valeurs ASCII sont dans l'ordre : Prol0gin
