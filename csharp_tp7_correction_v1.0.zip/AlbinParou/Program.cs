namespace HttpD
{
    public static class Program
    {
       public static void Main()
       {}
    }
}
