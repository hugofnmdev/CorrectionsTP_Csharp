﻿using System;

namespace Case1_HangedMan
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}