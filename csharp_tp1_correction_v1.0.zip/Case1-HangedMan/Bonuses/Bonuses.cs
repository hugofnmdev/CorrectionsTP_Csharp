﻿using System;

namespace Case1_HangedMan.Bonuses
{
    public class Bonuses
    {
        /*
         * This file can remain empty or you can customise it as you wish (add or remove prototypes)
         * You must log any bonuses done in your README and explain what they do and how to call them
         */
    }
}