namespace Monopoly
{
    public abstract class Cell
    {
        protected int position;

        public int Position => position;
    }
}