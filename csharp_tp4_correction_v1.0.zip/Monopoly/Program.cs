﻿namespace Monopoly
{
    class Program
    {
        static void Main()
        {
            Game game = Serializer.Load("../../../GameLayout/game");
            //Do not modify the line above
            game.DisplayBoard();
        }
    }
}