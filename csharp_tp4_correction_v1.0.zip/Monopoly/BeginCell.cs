namespace Monopoly
{
    public class BeginCell : Special
    {
        public override string ToString()
        {
            return "[Begin]";
        }
    }
}