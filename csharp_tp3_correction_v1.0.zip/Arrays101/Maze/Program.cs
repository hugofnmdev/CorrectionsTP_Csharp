﻿using System;

namespace Maze
{
    public static class Program
    {
        public static void Main()
        {
            Console.WriteLine("Hello World!");
        }
    }
}