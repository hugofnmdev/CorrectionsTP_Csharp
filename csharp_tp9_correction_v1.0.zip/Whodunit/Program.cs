using System;

namespace CurseCase
{
    class Program
    {
        static void Main()
        {
            // Tests please :
        }
    }
}
