using System;
using System.Collections.Generic;

namespace Warmup
{
    class Program
    {
        static void Main()
        {
            // This is where you can test your code, do not forget to remove
            // them when you are done !
        }
    }
}
